import UIKit

var greeting = "Hello, playground"

var cricketKit = ("handGloves" ,"helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))
var origin = (x : 0 , y : 0)
var point = origin
print(point)
